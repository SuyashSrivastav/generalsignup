const express = require("express");
const mongoose = require("mongoose");
const User = require("./models");

const app = express();

const port = 3030;

const MONGO_URL = "mongodb://localhost:27017/register";

// app.get('/',)

mongoose.connect(MONGO_URL, { useNewUrlParser: true });
const db = mongoose.connection;

db.on("error", (error) => console.log(error));
db.once("open", () => console.log("Conneted to DB!"));

app.post("/signup", async (req, res) => {
    try {
        const user = await User.create(req);

        res.status(200).send(user);
    } catch (e) {
        res.status(404).send(e);
    }
});

app.listen(port, () => {
    console.log(`Listening on the port ${port}!!!`);
});
